# VeinTreeMiner (Paper 1.12.2, Java 8)

One plugin that does two things:

- **Vein miner** - mine an ore with a good enough pickaxe and the whole connected vein breaks. No keybind needed.
  Respects Fortune / Silk Touch and gives the right XP.
- **Tree feller** - crouch and break the **bottom log** of a tree with an **axe** and the whole tree, leaves included, comes down.
  Leaf drops are **guaranteed** (not random): every leaf gives a sapling of its tree type + a stick, and oak / dark oak leaves also give an apple.
  Change the amounts (or switch to vanilla random drops) in `config.yml`.

## Build (GitHub Codespace or any machine with JDK 8+ and Maven)

    mvn -q clean package

The plugin is `target/VeinTreeMiner.jar`. It is compiled for Java 8 (class file version 52), so it loads on a Java 8 server.
Drop it in `plugins/` and restart.

If Maven can't download `paper-api:1.12.2-R0.1-SNAPSHOT`, put your own server jar on the classpath instead:
copy it to `libs/paper.jar` and replace the `<dependency>` in `pom.xml` with

    <dependency>
      <groupId>local</groupId>
      <artifactId>paper</artifactId>
      <version>1.12.2</version>
      <scope>system</scope>
      <systemPath>${project.basedir}/libs/paper.jar</systemPath>
    </dependency>

## Commands and permissions

| Command | What it does | Permission |
|---|---|---|
| `/veintree toggle` | turn vein miner + tree feller off/on for yourself (until restart) | - |
| `/veintree reload` | reload `config.yml` | `veintree.admin` (op) |

`veintree.vein` and `veintree.tree` (both default true) control who can use each feature.

## Notes

- Extra blocks fire a normal `BlockBreakEvent`, so claim / WorldGuard / logging plugins can veto them (`general.check-protection`).
  Some anti-cheats may notice many breaks in one tick; whitelist the plugin if so.
- Trunks need at least `tree-feller.min-leaves` connected leaves, so log cabins and pillars aren't felled.
- Leaves placed by players (they never decay) are left alone.
- Each extra block costs 1 durability (Unbreaking applies). The tree feller won't start if the axe can't afford the whole tree.
- Creative and spectator players are ignored.
