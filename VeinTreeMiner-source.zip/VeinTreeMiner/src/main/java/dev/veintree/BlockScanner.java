package dev.veintree;

import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

/** Flood fills used to find veins, trunks and leaves. Never loads chunks. */
final class BlockScanner {

    private static final BlockFace[] FACES = {
            BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST
    };

    private BlockScanner() {
    }

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }

    /**
     * All blocks matching {@code match} that are connected to {@code start} (diagonals count),
     * up to {@code max} blocks, never below {@code minY}. The start block itself is not in the result.
     */
    static List<Block> connected(Block start, int max, int minY, Predicate<Block> match) {
        World world = start.getWorld();
        List<Block> found = new ArrayList<Block>();
        Set<Long> seen = new HashSet<Long>();
        ArrayDeque<Block> queue = new ArrayDeque<Block>();

        seen.add(key(start.getX(), start.getY(), start.getZ()));
        queue.add(start);
        int floor = Math.max(0, minY);

        while (!queue.isEmpty()) {
            Block cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        int x = cur.getX() + dx;
                        int y = cur.getY() + dy;
                        int z = cur.getZ() + dz;
                        if (y < floor || y > 255) {
                            continue;
                        }
                        if (!seen.add(key(x, y, z))) {
                            continue;
                        }
                        if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                            continue;
                        }
                        Block next = world.getBlockAt(x, y, z);
                        if (!match.test(next)) {
                            continue;
                        }
                        found.add(next);
                        if (found.size() >= max) {
                            return found;
                        }
                        queue.add(next);
                    }
                }
            }
        }
        return found;
    }

    /**
     * Leaves of one type and species reachable from the given logs by stepping through
     * leaf blocks only, at most {@code maxDistance} steps away from a log.
     */
    static List<Block> leaves(List<Block> logs, Material leafType, int species, int maxDistance,
                              int max, boolean skipPlayerPlaced) {
        List<Block> result = new ArrayList<Block>();
        if (logs.isEmpty()) {
            return result;
        }
        World world = logs.get(0).getWorld();
        Set<Long> seen = new HashSet<Long>();
        List<Block> frontier = new ArrayList<Block>(logs);
        for (Block log : logs) {
            seen.add(key(log.getX(), log.getY(), log.getZ()));
        }

        for (int step = 1; step <= maxDistance && !frontier.isEmpty(); step++) {
            List<Block> next = new ArrayList<Block>();
            for (Block cur : frontier) {
                for (BlockFace face : FACES) {
                    int x = cur.getX() + face.getModX();
                    int y = cur.getY() + face.getModY();
                    int z = cur.getZ() + face.getModZ();
                    if (y < 0 || y > 255) {
                        continue;
                    }
                    if (!seen.add(key(x, y, z))) {
                        continue;
                    }
                    if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                        continue;
                    }
                    Block leaf = world.getBlockAt(x, y, z);
                    if (leaf.getType() != leafType) {
                        continue;
                    }
                    int data = leaf.getData();
                    if ((data & 3) != species) {
                        continue;
                    }
                    // bit 4 = "no decay": set on leaves a player placed
                    if (skipPlayerPlaced && (data & 4) != 0) {
                        continue;
                    }
                    result.add(leaf);
                    if (result.size() >= max) {
                        return result;
                    }
                    next.add(leaf);
                }
            }
            frontier = next;
        }
        return result;
    }
}
