package dev.veintree;

import org.bukkit.Effect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public final class BreakListener implements Listener {

    private final VeinTreeMiner plugin;
    private final Random random = new Random();
    /** Players whose extra breaks are being processed right now, so our own events don't re-trigger us. */
    private final Set<UUID> working = new HashSet<UUID>();

    BreakListener(VeinTreeMiner plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (working.contains(player.getUniqueId())) {
            return;
        }
        Settings s = plugin.settings();
        if (!eligible(player, s)) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (tool == null) {
            return;
        }

        Block block = event.getBlock();
        Material type = block.getType();

        if (s.veinEnabled && s.ores.contains(type) && player.hasPermission("veintree.vein")) {
            veinMine(player, block, tool, s);
        } else if (s.treeEnabled && (type == Material.LOG || type == Material.LOG_2)
                && player.hasPermission("veintree.tree")) {
            fellTree(player, block, tool, s);
        }
    }

    private boolean eligible(Player player, Settings s) {
        if (plugin.isDisabledFor(player.getUniqueId())) {
            return false;
        }
        GameMode mode = player.getGameMode();
        if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) {
            return false;
        }
        return !s.disabledWorlds.contains(player.getWorld().getName().toLowerCase(Locale.ROOT));
    }

    // ------------------------------------------------------------------ vein miner

    private void veinMine(Player player, Block origin, ItemStack tool, Settings s) {
        Material type = origin.getType();
        if (s.veinRequireSneak && !player.isSneaking()) {
            return;
        }
        // The pickaxe must be good enough for the ore to drop anything at all
        if (Tools.pickaxeTier(tool.getType()) < Tools.requiredTier(type)) {
            return;
        }

        final Material group = normalize(type);
        List<Block> vein = BlockScanner.connected(origin, s.veinMaxBlocks, 0,
                b -> normalize(b.getType()) == group);
        if (vein.isEmpty()) {
            return;
        }

        if (s.veinDurability) {
            int budget = Tools.budget(tool);
            if (budget <= 0) {
                return;
            }
            if (vein.size() > budget) {
                vein = new ArrayList<Block>(vein.subList(0, budget));
            }
        }

        DropBag bag = new DropBag();
        int xp = 0;
        int broken = 0;
        working.add(player.getUniqueId());
        try {
            for (Block b : vein) {
                if (s.checkProtection && !mayBreak(player, b)) {
                    continue;
                }
                xp += OreDrops.roll(b.getType(), tool, bag, random);
                effect(b, s);
                b.setType(Material.AIR);
                broken++;
            }
        } finally {
            working.remove(player.getUniqueId());
        }

        if (s.veinDurability) {
            Tools.damage(tool, broken, random);
        }
        deliver(player, center(origin), bag, xp, s);
    }

    private static Material normalize(Material m) {
        return m == Material.GLOWING_REDSTONE_ORE ? Material.REDSTONE_ORE : m;
    }

    // ------------------------------------------------------------------ tree feller

    private void fellTree(Player player, Block origin, ItemStack tool, Settings s) {
        if (s.treeRequireSneak && !player.isSneaking()) {
            return;
        }
        if (s.treeRequireAxe && !Tools.isAxe(tool.getType())) {
            return;
        }

        // Only the bottom log of a trunk starts a fell
        Material below = origin.getRelative(BlockFace.DOWN).getType();
        if (below == Material.LOG || below == Material.LOG_2) {
            return;
        }

        final Material logType = origin.getType();
        final int species = origin.getData() & 3;

        List<Block> logs = BlockScanner.connected(origin, s.treeMaxLogs, origin.getY(),
                b -> b.getType() == logType && (b.getData() & 3) == species);

        List<Block> trunk = new ArrayList<Block>(logs.size() + 1);
        trunk.add(origin);
        trunk.addAll(logs);

        Material leafType = logType == Material.LOG ? Material.LEAVES : Material.LEAVES_2;
        List<Block> leaves = BlockScanner.leaves(trunk, leafType, species, s.leafDistance,
                s.treeMaxLeaves, s.skipPlacedLeaves);

        // Not enough leaves: probably a log pillar or cabin, not a tree
        if (leaves.size() < s.treeMinLeaves) {
            return;
        }

        if (s.treeDurability && Tools.budget(tool) < logs.size()) {
            player.sendMessage(s.msgLowDurability);
            return;
        }

        DropBag bag = new DropBag();
        int brokenLogs = 0;
        working.add(player.getUniqueId());
        try {
            for (Block b : logs) {
                if (s.checkProtection && !mayBreak(player, b)) {
                    continue;
                }
                bag.add(logType, species, 1);
                effect(b, s);
                b.setType(Material.AIR);
                brokenLogs++;
            }
            for (Block b : leaves) {
                if (s.checkProtection && !mayBreak(player, b)) {
                    continue;
                }
                effect(b, s);
                switch (s.leafMode) {
                    case GUARANTEED:
                        addLeafDrops(b, s, bag);
                        b.setType(Material.AIR);
                        break;
                    case VANILLA:
                        b.breakNaturally(tool);
                        break;
                    default:
                        b.setType(Material.AIR);
                        break;
                }
            }
        } finally {
            working.remove(player.getUniqueId());
        }

        if (s.treeDurability) {
            Tools.damage(tool, brokenLogs, random);
        }
        deliver(player, center(origin), bag, 0, s);
    }

    /** Guaranteed leaf drops: the sapling for that tree type, sticks, and apples from oak / dark oak. */
    private void addLeafDrops(Block leaf, Settings s, DropBag bag) {
        Material type = leaf.getType();
        int species = leaf.getData() & 3;

        // Sapling data: 0 oak, 1 spruce, 2 birch, 3 jungle, 4 acacia, 5 dark oak
        int saplingData = type == Material.LEAVES_2 ? 4 + species : species;
        bag.add(Material.SAPLING, saplingData, s.saplingsPerLeaf);
        bag.add(Material.STICK, 0, s.sticksPerLeaf);

        boolean dropsApples = (type == Material.LEAVES && species == 0)
                || (type == Material.LEAVES_2 && species == 1);
        if (dropsApples) {
            bag.add(Material.APPLE, 0, s.applesPerLeaf);
        }
    }

    // ------------------------------------------------------------------ shared

    /** Asks other plugins (claims, WorldGuard, loggers...) whether this player may break the block. */
    private boolean mayBreak(Player player, Block block) {
        BlockBreakEvent test = new BlockBreakEvent(block, player);
        plugin.getServer().getPluginManager().callEvent(test);
        return !test.isCancelled();
    }

    private void effect(Block block, Settings s) {
        if (s.effects) {
            block.getWorld().playEffect(block.getLocation(), Effect.STEP_SOUND, block.getType());
        }
    }

    private static Location center(Block block) {
        return block.getLocation().add(0.5, 0.5, 0.5);
    }

    private void deliver(Player player, Location at, DropBag bag, int xp, Settings s) {
        World world = at.getWorld();
        if (s.dropsToInventory) {
            for (ItemStack stack : bag.stacks()) {
                Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
                for (ItemStack rest : leftover.values()) {
                    world.dropItemNaturally(player.getLocation(), rest);
                }
            }
            if (xp > 0) {
                player.giveExp(xp);
            }
        } else {
            for (ItemStack stack : bag.stacks()) {
                world.dropItemNaturally(at, stack);
            }
            if (xp > 0) {
                ExperienceOrb orb = world.spawn(at, ExperienceOrb.class);
                orb.setExperience(xp);
            }
        }
    }
}
