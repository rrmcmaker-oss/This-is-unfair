package dev.veintree;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Collects drops so hundreds of blocks become a handful of stacks instead of hundreds of item entities. */
final class DropBag {

    private final Map<String, ItemStack> items = new LinkedHashMap<String, ItemStack>();

    void add(Material type, int data, int amount) {
        if (amount <= 0) {
            return;
        }
        String key = type.name() + ":" + data;
        ItemStack stack = items.get(key);
        if (stack == null) {
            items.put(key, new ItemStack(type, amount, (short) data));
        } else {
            stack.setAmount(stack.getAmount() + amount);
        }
    }

    /** The collected drops, split into stacks no bigger than the item's max stack size. */
    List<ItemStack> stacks() {
        List<ItemStack> out = new ArrayList<ItemStack>();
        for (ItemStack stack : items.values()) {
            int left = stack.getAmount();
            int max = Math.max(1, stack.getMaxStackSize());
            while (left > 0) {
                int n = Math.min(max, left);
                ItemStack piece = stack.clone();
                piece.setAmount(n);
                out.add(piece);
                left -= n;
            }
        }
        return out;
    }
}
