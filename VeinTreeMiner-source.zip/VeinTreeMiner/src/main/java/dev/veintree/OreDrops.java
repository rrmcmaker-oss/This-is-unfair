package dev.veintree;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.util.Random;

/** Works out what an ore drops for a given tool (Silk Touch / Fortune) and how much XP it gives. */
final class OreDrops {

    private OreDrops() {
    }

    /** Adds the drops for one ore block to the bag and returns the XP it would give. */
    static int roll(Material ore, ItemStack tool, DropBag bag, Random r) {
        boolean silk = tool.getEnchantmentLevel(Enchantment.SILK_TOUCH) > 0;
        int fortune = tool.getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS);

        switch (ore) {
            case COAL_ORE:
                if (silk) {
                    bag.add(Material.COAL_ORE, 0, 1);
                    return 0;
                }
                bag.add(Material.COAL, 0, bonus(1, fortune, r));
                return xp(r, 0, 2);

            case DIAMOND_ORE:
                if (silk) {
                    bag.add(Material.DIAMOND_ORE, 0, 1);
                    return 0;
                }
                bag.add(Material.DIAMOND, 0, bonus(1, fortune, r));
                return xp(r, 3, 7);

            case EMERALD_ORE:
                if (silk) {
                    bag.add(Material.EMERALD_ORE, 0, 1);
                    return 0;
                }
                bag.add(Material.EMERALD, 0, bonus(1, fortune, r));
                return xp(r, 3, 7);

            case QUARTZ_ORE:
                if (silk) {
                    bag.add(Material.QUARTZ_ORE, 0, 1);
                    return 0;
                }
                bag.add(Material.QUARTZ, 0, bonus(1, fortune, r));
                return xp(r, 2, 5);

            case LAPIS_ORE:
                if (silk) {
                    bag.add(Material.LAPIS_ORE, 0, 1);
                    return 0;
                }
                // Lapis lazuli is ink sac with data value 4 in 1.12.2
                bag.add(Material.INK_SACK, 4, bonus(4 + r.nextInt(5), fortune, r));
                return xp(r, 2, 5);

            case REDSTONE_ORE:
            case GLOWING_REDSTONE_ORE:
                if (silk) {
                    bag.add(Material.REDSTONE_ORE, 0, 1);
                    return 0;
                }
                bag.add(Material.REDSTONE, 0, 4 + r.nextInt(2) + r.nextInt(fortune + 1));
                return xp(r, 1, 5);

            default:
                // Iron, gold and any other configured ore drop themselves
                bag.add(ore, 0, 1);
                return 0;
        }
    }

    /** Vanilla Fortune: multiplies the base count by 1 + max(0, random(fortune + 2) - 1). */
    private static int bonus(int base, int fortune, Random r) {
        if (fortune <= 0) {
            return base;
        }
        int multiplier = Math.max(r.nextInt(fortune + 2) - 1, 0) + 1;
        return base * multiplier;
    }

    private static int xp(Random r, int min, int max) {
        return min + r.nextInt(max - min + 1);
    }
}
