package dev.veintree;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Immutable snapshot of config.yml. */
final class Settings {

    enum LeafMode { GUARANTEED, VANILLA, NONE }

    // general
    final boolean dropsToInventory;
    final boolean checkProtection;
    final boolean effects;
    final Set<String> disabledWorlds;

    // vein miner
    final boolean veinEnabled;
    final boolean veinRequireSneak;
    final int veinMaxBlocks;
    final boolean veinDurability;
    final Set<Material> ores;

    // tree feller
    final boolean treeEnabled;
    final boolean treeRequireSneak;
    final boolean treeRequireAxe;
    final int treeMaxLogs;
    final int treeMaxLeaves;
    final int leafDistance;
    final int treeMinLeaves;
    final boolean skipPlacedLeaves;
    final boolean treeDurability;
    final LeafMode leafMode;
    final int saplingsPerLeaf;
    final int sticksPerLeaf;
    final int applesPerLeaf;

    // messages
    final String msgLowDurability;

    Settings(FileConfiguration c) {
        dropsToInventory = c.getBoolean("general.drops-to-inventory", false);
        checkProtection = c.getBoolean("general.check-protection", true);
        effects = c.getBoolean("general.break-effects", true);
        Set<String> worlds = new HashSet<String>();
        for (String w : c.getStringList("general.disabled-worlds")) {
            worlds.add(w.trim().toLowerCase(Locale.ROOT));
        }
        disabledWorlds = worlds;

        veinEnabled = c.getBoolean("vein-miner.enabled", true);
        veinRequireSneak = c.getBoolean("vein-miner.require-sneak", false);
        veinMaxBlocks = Math.max(1, c.getInt("vein-miner.max-blocks", 64));
        veinDurability = c.getBoolean("vein-miner.consume-durability", true);
        Set<Material> found = EnumSet.noneOf(Material.class);
        for (String name : c.getStringList("vein-miner.ores")) {
            Material m = Material.matchMaterial(name.trim());
            if (m != null) {
                found.add(m);
            }
        }
        // Redstone ore turns into the "glowing" variant when touched
        if (found.contains(Material.REDSTONE_ORE)) {
            found.add(Material.GLOWING_REDSTONE_ORE);
        }
        ores = found;

        treeEnabled = c.getBoolean("tree-feller.enabled", true);
        treeRequireSneak = c.getBoolean("tree-feller.require-sneak", true);
        treeRequireAxe = c.getBoolean("tree-feller.require-axe", true);
        treeMaxLogs = Math.max(1, c.getInt("tree-feller.max-logs", 300));
        treeMaxLeaves = Math.max(0, c.getInt("tree-feller.max-leaves", 1500));
        leafDistance = Math.max(1, c.getInt("tree-feller.leaf-distance", 4));
        treeMinLeaves = Math.max(0, c.getInt("tree-feller.min-leaves", 3));
        skipPlacedLeaves = c.getBoolean("tree-feller.skip-player-placed-leaves", true);
        treeDurability = c.getBoolean("tree-feller.consume-durability", true);

        LeafMode mode;
        try {
            mode = LeafMode.valueOf(c.getString("tree-feller.leaf-drops.mode", "GUARANTEED")
                    .trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            mode = LeafMode.GUARANTEED;
        }
        leafMode = mode;
        saplingsPerLeaf = Math.max(0, c.getInt("tree-feller.leaf-drops.saplings-per-leaf", 1));
        sticksPerLeaf = Math.max(0, c.getInt("tree-feller.leaf-drops.sticks-per-leaf", 1));
        applesPerLeaf = Math.max(0, c.getInt("tree-feller.leaf-drops.apples-per-leaf", 1));

        msgLowDurability = ChatColor.translateAlternateColorCodes('&',
                c.getString("messages.low-durability",
                        "&cYour axe doesn't have enough durability to fell this tree."));
    }
}
