package dev.veintree;

import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.util.Random;

/** Tool helpers for Minecraft 1.12.2 material names. */
final class Tools {

    private Tools() {
    }

    static boolean isAxe(Material m) {
        switch (m) {
            case WOOD_AXE:
            case STONE_AXE:
            case IRON_AXE:
            case GOLD_AXE:
            case DIAMOND_AXE:
                return true;
            default:
                return false;
        }
    }

    /** Harvest tier of a pickaxe: wood/gold 0, stone 1, iron 2, diamond 3, anything else -1. */
    static int pickaxeTier(Material m) {
        switch (m) {
            case WOOD_PICKAXE:
            case GOLD_PICKAXE:
                return 0;
            case STONE_PICKAXE:
                return 1;
            case IRON_PICKAXE:
                return 2;
            case DIAMOND_PICKAXE:
                return 3;
            default:
                return -1;
        }
    }

    /** Minimum pickaxe tier for an ore to drop anything. */
    static int requiredTier(Material ore) {
        switch (ore) {
            case IRON_ORE:
            case LAPIS_ORE:
                return 1;
            case GOLD_ORE:
            case DIAMOND_ORE:
            case EMERALD_ORE:
            case REDSTONE_ORE:
            case GLOWING_REDSTONE_ORE:
                return 2;
            default:
                return 0;
        }
    }

    /**
     * How many extra uses the tool can afford. One point is always kept back for the
     * normal damage the game applies to the block the player broke themselves.
     */
    static int budget(ItemStack tool) {
        short max = tool.getType().getMaxDurability();
        if (max <= 0) {
            return Integer.MAX_VALUE;
        }
        return Math.max(0, max - tool.getDurability() - 1);
    }

    /** Applies durability damage for {@code uses} extra blocks, honouring Unbreaking. */
    static void damage(ItemStack tool, int uses, Random random) {
        short max = tool.getType().getMaxDurability();
        if (max <= 0 || uses <= 0) {
            return;
        }
        int unbreaking = tool.getEnchantmentLevel(Enchantment.DURABILITY);
        int damage = 0;
        for (int i = 0; i < uses; i++) {
            if (unbreaking <= 0 || random.nextInt(unbreaking + 1) == 0) {
                damage++;
            }
        }
        int newDamage = Math.min(max - 1, tool.getDurability() + damage);
        tool.setDurability((short) newDamage);
    }
}
