package dev.veintree;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class VeinTreeMiner extends JavaPlugin {

    private volatile Settings settings;
    /** Players who switched the plugin off for themselves with /veintree toggle (until restart). */
    private final Set<UUID> disabled = new HashSet<UUID>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(getConfig());
        getServer().getPluginManager().registerEvents(new BreakListener(this), this);
        getLogger().info("Vein miner: " + settings.ores.size() + " ore types. Tree feller: "
                + (settings.treeEnabled ? "on" : "off") + ".");
    }

    Settings settings() {
        return settings;
    }

    boolean isDisabledFor(UUID id) {
        return disabled.contains(id);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("veintree.admin")) {
                sender.sendMessage(ChatColor.RED + "You don't have permission to do that.");
                return true;
            }
            reloadConfig();
            settings = new Settings(getConfig());
            sender.sendMessage(ChatColor.GREEN + "VeinTreeMiner config reloaded.");
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("toggle")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Only players can toggle this.");
                return true;
            }
            UUID id = ((Player) sender).getUniqueId();
            if (disabled.remove(id)) {
                sender.sendMessage(ChatColor.GREEN + "Vein miner and tree feller are ON for you.");
            } else {
                disabled.add(id);
                sender.sendMessage(ChatColor.YELLOW + "Vein miner and tree feller are OFF for you.");
            }
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Usage: /" + label + " toggle | reload");
        return true;
    }
}
